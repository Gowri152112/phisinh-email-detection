phishing_keywords = [
    "urgent",
    "verify account",
    "click here",
    "winner",
    "free money",
    "bank details",
    "password"
]

email = input("Enter Email Content: ").lower()

phishing_score = 0

for word in phishing_keywords:
    if word in email:
        phishing_score += 1

print("\nEmail Analysis Result")

if phishing_score >= 2:
    print("Phishing Email Detected")
else:
    print("Safe Email")